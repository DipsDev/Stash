from flask_login import LoginManager

login_manager = LoginManager()
