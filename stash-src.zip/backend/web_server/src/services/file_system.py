from api.file_system import FileSystem

file_system = FileSystem(r"D:\code\stash\backend\__temp__")